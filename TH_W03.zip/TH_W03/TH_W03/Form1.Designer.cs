﻿namespace TH_W03
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Uname = new System.Windows.Forms.Label();
            this.btn_Login = new System.Windows.Forms.Button();
            this.txtbox_Uname = new System.Windows.Forms.TextBox();
            this.txtbox_Password = new System.Windows.Forms.TextBox();
            this.lbl_Password = new System.Windows.Forms.Label();
            this.btn_Regist = new System.Windows.Forms.Button();
            this.lbl_Judul = new System.Windows.Forms.Label();
            this.pnl_Login = new System.Windows.Forms.Panel();
            this.pnl_Withdraw = new System.Windows.Forms.Panel();
            this.lbl_BalanceWithdraw = new System.Windows.Forms.Label();
            this.lbl_wdBalance = new System.Windows.Forms.Label();
            this.txtbox_Withdraw = new System.Windows.Forms.TextBox();
            this.lbl_Logout3 = new System.Windows.Forms.Button();
            this.lbl_JudulWithdraw = new System.Windows.Forms.Label();
            this.btn_NewWithdraw = new System.Windows.Forms.Button();
            this.lbl_Withdraw = new System.Windows.Forms.Label();
            this.pnl_Regist = new System.Windows.Forms.Panel();
            this.lbl_Regist = new System.Windows.Forms.Label();
            this.lbl_NewUname = new System.Windows.Forms.Label();
            this.btn_NewRegist = new System.Windows.Forms.Button();
            this.txtbox_NewPass = new System.Windows.Forms.TextBox();
            this.txtbox_NewUname = new System.Windows.Forms.TextBox();
            this.lbl_NewPass = new System.Windows.Forms.Label();
            this.pnl_Main = new System.Windows.Forms.Panel();
            this.btn_Logout = new System.Windows.Forms.Button();
            this.btn_Withdraw = new System.Windows.Forms.Button();
            this.lbl_Main = new System.Windows.Forms.Label();
            this.lbl_RpBalance = new System.Windows.Forms.Label();
            this.btn_Deposit = new System.Windows.Forms.Button();
            this.lbl_Balance = new System.Windows.Forms.Label();
            this.pnl_Deposit = new System.Windows.Forms.Panel();
            this.txtbox_Deposit = new System.Windows.Forms.TextBox();
            this.btn_Logout2 = new System.Windows.Forms.Button();
            this.lbl_JudulDeposit = new System.Windows.Forms.Label();
            this.btn_NewDeposit = new System.Windows.Forms.Button();
            this.lbl_Input = new System.Windows.Forms.Label();
            this.pnl_Login.SuspendLayout();
            this.pnl_Withdraw.SuspendLayout();
            this.pnl_Regist.SuspendLayout();
            this.pnl_Main.SuspendLayout();
            this.pnl_Deposit.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_Uname
            // 
            this.lbl_Uname.AutoSize = true;
            this.lbl_Uname.Location = new System.Drawing.Point(13, 96);
            this.lbl_Uname.Name = "lbl_Uname";
            this.lbl_Uname.Size = new System.Drawing.Size(55, 13);
            this.lbl_Uname.TabIndex = 0;
            this.lbl_Uname.Text = "Username";
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(59, 155);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(75, 23);
            this.btn_Login.TabIndex = 1;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // txtbox_Uname
            // 
            this.txtbox_Uname.Location = new System.Drawing.Point(83, 93);
            this.txtbox_Uname.Name = "txtbox_Uname";
            this.txtbox_Uname.Size = new System.Drawing.Size(100, 20);
            this.txtbox_Uname.TabIndex = 2;
            // 
            // txtbox_Password
            // 
            this.txtbox_Password.Location = new System.Drawing.Point(83, 119);
            this.txtbox_Password.Name = "txtbox_Password";
            this.txtbox_Password.Size = new System.Drawing.Size(100, 20);
            this.txtbox_Password.TabIndex = 4;
            // 
            // lbl_Password
            // 
            this.lbl_Password.AutoSize = true;
            this.lbl_Password.Location = new System.Drawing.Point(13, 122);
            this.lbl_Password.Name = "lbl_Password";
            this.lbl_Password.Size = new System.Drawing.Size(53, 13);
            this.lbl_Password.TabIndex = 3;
            this.lbl_Password.Text = "Password";
            // 
            // btn_Regist
            // 
            this.btn_Regist.Location = new System.Drawing.Point(59, 184);
            this.btn_Regist.Name = "btn_Regist";
            this.btn_Regist.Size = new System.Drawing.Size(75, 23);
            this.btn_Regist.TabIndex = 5;
            this.btn_Regist.Text = "Register";
            this.btn_Regist.UseVisualStyleBackColor = true;
            this.btn_Regist.Click += new System.EventHandler(this.btn_Regist_Click);
            // 
            // lbl_Judul
            // 
            this.lbl_Judul.AutoSize = true;
            this.lbl_Judul.Font = new System.Drawing.Font("Keep on Truckin", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Judul.Location = new System.Drawing.Point(21, 22);
            this.lbl_Judul.Name = "lbl_Judul";
            this.lbl_Judul.Size = new System.Drawing.Size(157, 37);
            this.lbl_Judul.TabIndex = 6;
            this.lbl_Judul.Text = "UC Bank";
            // 
            // pnl_Login
            // 
            this.pnl_Login.Controls.Add(this.lbl_Judul);
            this.pnl_Login.Controls.Add(this.lbl_Uname);
            this.pnl_Login.Controls.Add(this.btn_Regist);
            this.pnl_Login.Controls.Add(this.btn_Login);
            this.pnl_Login.Controls.Add(this.txtbox_Password);
            this.pnl_Login.Controls.Add(this.txtbox_Uname);
            this.pnl_Login.Controls.Add(this.lbl_Password);
            this.pnl_Login.Location = new System.Drawing.Point(0, 0);
            this.pnl_Login.Name = "pnl_Login";
            this.pnl_Login.Size = new System.Drawing.Size(200, 229);
            this.pnl_Login.TabIndex = 7;
            // 
            // pnl_Withdraw
            // 
            this.pnl_Withdraw.Controls.Add(this.lbl_BalanceWithdraw);
            this.pnl_Withdraw.Controls.Add(this.lbl_wdBalance);
            this.pnl_Withdraw.Controls.Add(this.txtbox_Withdraw);
            this.pnl_Withdraw.Controls.Add(this.lbl_Logout3);
            this.pnl_Withdraw.Controls.Add(this.lbl_JudulWithdraw);
            this.pnl_Withdraw.Controls.Add(this.btn_NewWithdraw);
            this.pnl_Withdraw.Controls.Add(this.lbl_Withdraw);
            this.pnl_Withdraw.Location = new System.Drawing.Point(9, 9);
            this.pnl_Withdraw.Name = "pnl_Withdraw";
            this.pnl_Withdraw.Size = new System.Drawing.Size(200, 229);
            this.pnl_Withdraw.TabIndex = 11;
            this.pnl_Withdraw.Visible = false;
            // 
            // lbl_BalanceWithdraw
            // 
            this.lbl_BalanceWithdraw.AutoSize = true;
            this.lbl_BalanceWithdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_BalanceWithdraw.Location = new System.Drawing.Point(76, 115);
            this.lbl_BalanceWithdraw.Name = "lbl_BalanceWithdraw";
            this.lbl_BalanceWithdraw.Size = new System.Drawing.Size(55, 18);
            this.lbl_BalanceWithdraw.TabIndex = 9;
            this.lbl_BalanceWithdraw.Text = "Rp0,00";
            // 
            // lbl_wdBalance
            // 
            this.lbl_wdBalance.AutoSize = true;
            this.lbl_wdBalance.Location = new System.Drawing.Point(24, 118);
            this.lbl_wdBalance.Name = "lbl_wdBalance";
            this.lbl_wdBalance.Size = new System.Drawing.Size(46, 13);
            this.lbl_wdBalance.TabIndex = 10;
            this.lbl_wdBalance.Text = "Balance";
            this.lbl_wdBalance.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtbox_Withdraw
            // 
            this.txtbox_Withdraw.Location = new System.Drawing.Point(50, 162);
            this.txtbox_Withdraw.Name = "txtbox_Withdraw";
            this.txtbox_Withdraw.Size = new System.Drawing.Size(100, 20);
            this.txtbox_Withdraw.TabIndex = 9;
            // 
            // lbl_Logout3
            // 
            this.lbl_Logout3.Location = new System.Drawing.Point(103, 73);
            this.lbl_Logout3.Name = "lbl_Logout3";
            this.lbl_Logout3.Size = new System.Drawing.Size(75, 23);
            this.lbl_Logout3.TabIndex = 8;
            this.lbl_Logout3.Text = "Log Out";
            this.lbl_Logout3.UseVisualStyleBackColor = true;
            this.lbl_Logout3.Click += new System.EventHandler(this.btn_Logout_Click_1);
            // 
            // lbl_JudulWithdraw
            // 
            this.lbl_JudulWithdraw.AutoSize = true;
            this.lbl_JudulWithdraw.Font = new System.Drawing.Font("Keep on Truckin", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_JudulWithdraw.Location = new System.Drawing.Point(21, 22);
            this.lbl_JudulWithdraw.Name = "lbl_JudulWithdraw";
            this.lbl_JudulWithdraw.Size = new System.Drawing.Size(157, 37);
            this.lbl_JudulWithdraw.TabIndex = 6;
            this.lbl_JudulWithdraw.Text = "UC Bank";
            // 
            // btn_NewWithdraw
            // 
            this.btn_NewWithdraw.Location = new System.Drawing.Point(63, 194);
            this.btn_NewWithdraw.Name = "btn_NewWithdraw";
            this.btn_NewWithdraw.Size = new System.Drawing.Size(75, 23);
            this.btn_NewWithdraw.TabIndex = 5;
            this.btn_NewWithdraw.Text = "Withdraw";
            this.btn_NewWithdraw.UseVisualStyleBackColor = true;
            this.btn_NewWithdraw.Click += new System.EventHandler(this.btn_NewWithdraw_Click);
            // 
            // lbl_Withdraw
            // 
            this.lbl_Withdraw.AutoSize = true;
            this.lbl_Withdraw.Location = new System.Drawing.Point(37, 139);
            this.lbl_Withdraw.Name = "lbl_Withdraw";
            this.lbl_Withdraw.Size = new System.Drawing.Size(129, 13);
            this.lbl_Withdraw.TabIndex = 3;
            this.lbl_Withdraw.Text = "Input Withdrawal Amount:";
            this.lbl_Withdraw.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_Regist
            // 
            this.pnl_Regist.Controls.Add(this.lbl_Regist);
            this.pnl_Regist.Controls.Add(this.lbl_NewUname);
            this.pnl_Regist.Controls.Add(this.btn_NewRegist);
            this.pnl_Regist.Controls.Add(this.txtbox_NewPass);
            this.pnl_Regist.Controls.Add(this.txtbox_NewUname);
            this.pnl_Regist.Controls.Add(this.lbl_NewPass);
            this.pnl_Regist.Location = new System.Drawing.Point(0, 0);
            this.pnl_Regist.Name = "pnl_Regist";
            this.pnl_Regist.Size = new System.Drawing.Size(200, 229);
            this.pnl_Regist.TabIndex = 8;
            this.pnl_Regist.Visible = false;
            // 
            // lbl_Regist
            // 
            this.lbl_Regist.AutoSize = true;
            this.lbl_Regist.Font = new System.Drawing.Font("Keep on Truckin", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Regist.Location = new System.Drawing.Point(21, 22);
            this.lbl_Regist.Name = "lbl_Regist";
            this.lbl_Regist.Size = new System.Drawing.Size(157, 37);
            this.lbl_Regist.TabIndex = 6;
            this.lbl_Regist.Text = "UC Bank";
            // 
            // lbl_NewUname
            // 
            this.lbl_NewUname.AutoSize = true;
            this.lbl_NewUname.Location = new System.Drawing.Point(13, 96);
            this.lbl_NewUname.Name = "lbl_NewUname";
            this.lbl_NewUname.Size = new System.Drawing.Size(55, 13);
            this.lbl_NewUname.TabIndex = 0;
            this.lbl_NewUname.Text = "Username";
            // 
            // btn_NewRegist
            // 
            this.btn_NewRegist.Location = new System.Drawing.Point(58, 165);
            this.btn_NewRegist.Name = "btn_NewRegist";
            this.btn_NewRegist.Size = new System.Drawing.Size(75, 23);
            this.btn_NewRegist.TabIndex = 5;
            this.btn_NewRegist.Text = "Register";
            this.btn_NewRegist.UseVisualStyleBackColor = true;
            this.btn_NewRegist.Click += new System.EventHandler(this.btn_NewRegist_Click);
            // 
            // txtbox_NewPass
            // 
            this.txtbox_NewPass.Location = new System.Drawing.Point(83, 119);
            this.txtbox_NewPass.Name = "txtbox_NewPass";
            this.txtbox_NewPass.Size = new System.Drawing.Size(100, 20);
            this.txtbox_NewPass.TabIndex = 4;
            // 
            // txtbox_NewUname
            // 
            this.txtbox_NewUname.Location = new System.Drawing.Point(83, 93);
            this.txtbox_NewUname.Name = "txtbox_NewUname";
            this.txtbox_NewUname.Size = new System.Drawing.Size(100, 20);
            this.txtbox_NewUname.TabIndex = 2;
            // 
            // lbl_NewPass
            // 
            this.lbl_NewPass.AutoSize = true;
            this.lbl_NewPass.Location = new System.Drawing.Point(13, 122);
            this.lbl_NewPass.Name = "lbl_NewPass";
            this.lbl_NewPass.Size = new System.Drawing.Size(53, 13);
            this.lbl_NewPass.TabIndex = 3;
            this.lbl_NewPass.Text = "Password";
            // 
            // pnl_Main
            // 
            this.pnl_Main.Controls.Add(this.btn_Logout);
            this.pnl_Main.Controls.Add(this.btn_Withdraw);
            this.pnl_Main.Controls.Add(this.lbl_Main);
            this.pnl_Main.Controls.Add(this.lbl_RpBalance);
            this.pnl_Main.Controls.Add(this.btn_Deposit);
            this.pnl_Main.Controls.Add(this.lbl_Balance);
            this.pnl_Main.Location = new System.Drawing.Point(0, 0);
            this.pnl_Main.Name = "pnl_Main";
            this.pnl_Main.Size = new System.Drawing.Size(200, 229);
            this.pnl_Main.TabIndex = 9;
            this.pnl_Main.Visible = false;
            // 
            // btn_Logout
            // 
            this.btn_Logout.Location = new System.Drawing.Point(103, 73);
            this.btn_Logout.Name = "btn_Logout";
            this.btn_Logout.Size = new System.Drawing.Size(75, 23);
            this.btn_Logout.TabIndex = 8;
            this.btn_Logout.Text = "Log Out";
            this.btn_Logout.UseVisualStyleBackColor = true;
            this.btn_Logout.Click += new System.EventHandler(this.btn_Logout_Click_1);
            // 
            // btn_Withdraw
            // 
            this.btn_Withdraw.Location = new System.Drawing.Point(57, 177);
            this.btn_Withdraw.Name = "btn_Withdraw";
            this.btn_Withdraw.Size = new System.Drawing.Size(75, 23);
            this.btn_Withdraw.TabIndex = 7;
            this.btn_Withdraw.Text = "Withdraw";
            this.btn_Withdraw.UseVisualStyleBackColor = true;
            this.btn_Withdraw.Click += new System.EventHandler(this.btn_Withdraw_Click);
            // 
            // lbl_Main
            // 
            this.lbl_Main.AutoSize = true;
            this.lbl_Main.Font = new System.Drawing.Font("Keep on Truckin", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Main.Location = new System.Drawing.Point(21, 22);
            this.lbl_Main.Name = "lbl_Main";
            this.lbl_Main.Size = new System.Drawing.Size(157, 37);
            this.lbl_Main.TabIndex = 6;
            this.lbl_Main.Text = "UC Bank";
            // 
            // lbl_RpBalance
            // 
            this.lbl_RpBalance.AutoSize = true;
            this.lbl_RpBalance.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_RpBalance.Location = new System.Drawing.Point(88, 117);
            this.lbl_RpBalance.Name = "lbl_RpBalance";
            this.lbl_RpBalance.Size = new System.Drawing.Size(55, 18);
            this.lbl_RpBalance.TabIndex = 0;
            this.lbl_RpBalance.Text = "Rp0,00";
            // 
            // btn_Deposit
            // 
            this.btn_Deposit.Location = new System.Drawing.Point(57, 148);
            this.btn_Deposit.Name = "btn_Deposit";
            this.btn_Deposit.Size = new System.Drawing.Size(75, 23);
            this.btn_Deposit.TabIndex = 5;
            this.btn_Deposit.Text = "Deposit";
            this.btn_Deposit.UseVisualStyleBackColor = true;
            this.btn_Deposit.Click += new System.EventHandler(this.btn_Deposit_Click);
            // 
            // lbl_Balance
            // 
            this.lbl_Balance.AutoSize = true;
            this.lbl_Balance.Location = new System.Drawing.Point(36, 120);
            this.lbl_Balance.Name = "lbl_Balance";
            this.lbl_Balance.Size = new System.Drawing.Size(46, 13);
            this.lbl_Balance.TabIndex = 3;
            this.lbl_Balance.Text = "Balance";
            this.lbl_Balance.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pnl_Deposit
            // 
            this.pnl_Deposit.Controls.Add(this.txtbox_Deposit);
            this.pnl_Deposit.Controls.Add(this.btn_Logout2);
            this.pnl_Deposit.Controls.Add(this.lbl_JudulDeposit);
            this.pnl_Deposit.Controls.Add(this.btn_NewDeposit);
            this.pnl_Deposit.Controls.Add(this.lbl_Input);
            this.pnl_Deposit.Location = new System.Drawing.Point(0, 0);
            this.pnl_Deposit.Name = "pnl_Deposit";
            this.pnl_Deposit.Size = new System.Drawing.Size(200, 229);
            this.pnl_Deposit.TabIndex = 10;
            this.pnl_Deposit.Visible = false;
            // 
            // txtbox_Deposit
            // 
            this.txtbox_Deposit.Location = new System.Drawing.Point(50, 145);
            this.txtbox_Deposit.Name = "txtbox_Deposit";
            this.txtbox_Deposit.Size = new System.Drawing.Size(100, 20);
            this.txtbox_Deposit.TabIndex = 9;
            // 
            // btn_Logout2
            // 
            this.btn_Logout2.Location = new System.Drawing.Point(103, 73);
            this.btn_Logout2.Name = "btn_Logout2";
            this.btn_Logout2.Size = new System.Drawing.Size(75, 23);
            this.btn_Logout2.TabIndex = 8;
            this.btn_Logout2.Text = "Log Out";
            this.btn_Logout2.UseVisualStyleBackColor = true;
            this.btn_Logout2.Click += new System.EventHandler(this.btn_Logout_Click_1);
            // 
            // lbl_JudulDeposit
            // 
            this.lbl_JudulDeposit.AutoSize = true;
            this.lbl_JudulDeposit.Font = new System.Drawing.Font("Keep on Truckin", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_JudulDeposit.Location = new System.Drawing.Point(21, 22);
            this.lbl_JudulDeposit.Name = "lbl_JudulDeposit";
            this.lbl_JudulDeposit.Size = new System.Drawing.Size(157, 37);
            this.lbl_JudulDeposit.TabIndex = 6;
            this.lbl_JudulDeposit.Text = "UC Bank";
            // 
            // btn_NewDeposit
            // 
            this.btn_NewDeposit.Location = new System.Drawing.Point(63, 177);
            this.btn_NewDeposit.Name = "btn_NewDeposit";
            this.btn_NewDeposit.Size = new System.Drawing.Size(75, 23);
            this.btn_NewDeposit.TabIndex = 5;
            this.btn_NewDeposit.Text = "Deposit";
            this.btn_NewDeposit.UseVisualStyleBackColor = true;
            this.btn_NewDeposit.Click += new System.EventHandler(this.btn_NewDeposit_Click);
            // 
            // lbl_Input
            // 
            this.lbl_Input.AutoSize = true;
            this.lbl_Input.Location = new System.Drawing.Point(47, 122);
            this.lbl_Input.Name = "lbl_Input";
            this.lbl_Input.Size = new System.Drawing.Size(112, 13);
            this.lbl_Input.TabIndex = 3;
            this.lbl_Input.Text = "Input Deposit Amount:";
            this.lbl_Input.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(233, 255);
            this.Controls.Add(this.pnl_Main);
            this.Controls.Add(this.pnl_Regist);
            this.Controls.Add(this.pnl_Login);
            this.Controls.Add(this.pnl_Deposit);
            this.Controls.Add(this.pnl_Withdraw);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnl_Login.ResumeLayout(false);
            this.pnl_Login.PerformLayout();
            this.pnl_Withdraw.ResumeLayout(false);
            this.pnl_Withdraw.PerformLayout();
            this.pnl_Regist.ResumeLayout(false);
            this.pnl_Regist.PerformLayout();
            this.pnl_Main.ResumeLayout(false);
            this.pnl_Main.PerformLayout();
            this.pnl_Deposit.ResumeLayout(false);
            this.pnl_Deposit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_Uname;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.TextBox txtbox_Uname;
        private System.Windows.Forms.TextBox txtbox_Password;
        private System.Windows.Forms.Label lbl_Password;
        private System.Windows.Forms.Button btn_Regist;
        private System.Windows.Forms.Label lbl_Judul;
        private System.Windows.Forms.Panel pnl_Login;
        private System.Windows.Forms.Panel pnl_Regist;
        private System.Windows.Forms.Label lbl_Regist;
        private System.Windows.Forms.Label lbl_NewUname;
        private System.Windows.Forms.Button btn_NewRegist;
        private System.Windows.Forms.TextBox txtbox_NewPass;
        private System.Windows.Forms.TextBox txtbox_NewUname;
        private System.Windows.Forms.Label lbl_NewPass;
        private System.Windows.Forms.Panel pnl_Main;
        private System.Windows.Forms.Label lbl_Main;
        private System.Windows.Forms.Label lbl_RpBalance;
        private System.Windows.Forms.Button btn_Deposit;
        private System.Windows.Forms.Label lbl_Balance;
        private System.Windows.Forms.Button btn_Logout;
        private System.Windows.Forms.Button btn_Withdraw;
        private System.Windows.Forms.Panel pnl_Deposit;
        private System.Windows.Forms.TextBox txtbox_Deposit;
        private System.Windows.Forms.Button btn_Logout2;
        private System.Windows.Forms.Label lbl_JudulDeposit;
        private System.Windows.Forms.Button btn_NewDeposit;
        private System.Windows.Forms.Label lbl_Input;
        private System.Windows.Forms.Panel pnl_Withdraw;
        private System.Windows.Forms.Label lbl_BalanceWithdraw;
        private System.Windows.Forms.Label lbl_wdBalance;
        private System.Windows.Forms.TextBox txtbox_Withdraw;
        private System.Windows.Forms.Button lbl_Logout3;
        private System.Windows.Forms.Label lbl_JudulWithdraw;
        private System.Windows.Forms.Button btn_NewWithdraw;
        private System.Windows.Forms.Label lbl_Withdraw;
    }
}

