﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TH_W03
{
    public partial class Form1 : Form
    {
        DataTable dtUser = new DataTable();
        string username;
        int index = 0;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            dtUser.Columns.Add("Username");
            dtUser.Columns.Add("Password");
            dtUser.Columns.Add("Balance");
        }
        private void btn_Regist_Click(object sender, EventArgs e)
        {
            pnl_Login.Visible = false;
            pnl_Regist.Visible = true;
            txtbox_Uname.Clear();
            txtbox_Password.Clear();
        }

        private void btn_NewRegist_Click(object sender, EventArgs e)
        {
            bool kembar = false;
            for (int i = 0; i < dtUser.Rows.Count; i++)
            {
                if (dtUser.Rows[i][0].ToString() == txtbox_NewUname.Text)
                    kembar = true;
            }
            if (kembar == false)
            {
                dtUser.Rows.Add(txtbox_NewUname.Text, txtbox_NewPass.Text, 0);
                MessageBox.Show("Register Successful");
                pnl_Regist.Visible = false;
                pnl_Login.Visible = true;
                txtbox_NewUname.Clear();
                txtbox_NewPass.Clear();
            }
            else
            {
                MessageBox.Show("Username has been used");
            }
        }
        private void btn_Login_Click(object sender, EventArgs e)
        {
            bool registed = false;
            for (int i = 0; i < dtUser.Rows.Count; i++)
            {
                if (dtUser.Rows[i][0].ToString() == txtbox_Uname.Text)
                {
                    registed = true;
                    index = i;
                }

            }
            if(registed == true)
            {
                MessageBox.Show("Login Successful");
                pnl_Login.Visible = false;
                pnl_Main.Visible = true;
                username = txtbox_Uname.Text;
                lbl_RpBalance.Text = Convert.ToDouble(dtUser.Rows[index][2]).ToString("C2").Remove(1,0);
                txtbox_Uname.Clear();
                txtbox_Password.Clear();
            }
            else
            {
                MessageBox.Show("No User Found");
            }
        }

        private void btn_Deposit_Click(object sender, EventArgs e)
        {
            pnl_Main.Visible = false;
            pnl_Deposit.Visible = true;
        }

        private void btn_NewDeposit_Click(object sender, EventArgs e)
        {
            double deposit = Convert.ToDouble(txtbox_Deposit.Text);
            if(deposit > 0)
            {
                MessageBox.Show("Successfully Add Deposit");
                dtUser.Rows[index][2] = Convert.ToDouble(dtUser.Rows[index][2]) + deposit;
                lbl_RpBalance.Text = Convert.ToDouble(dtUser.Rows[index][2]).ToString("C2").Remove(1,0);
                
                pnl_Deposit.Visible = false;
                pnl_Main.Visible = true;
                txtbox_Deposit.Clear();
            }
            else
            {
                MessageBox.Show("Deposit Amount Can't be Less Than 1");
                pnl_Deposit.Visible = false;
                pnl_Main.Visible = true;
                txtbox_Deposit.Clear();
            }
        }

        private void btn_Withdraw_Click(object sender, EventArgs e)
        {
            pnl_Main.Visible = false;
            pnl_Withdraw.Visible = true;
            lbl_BalanceWithdraw.Text = Convert.ToDouble(dtUser.Rows[index][2]).ToString("C2").Remove(1, 0);
        }

        private void btn_NewWithdraw_Click(object sender, EventArgs e)
        {
            lbl_BalanceWithdraw.Text = lbl_RpBalance.Text;
            if (Convert.ToDouble(txtbox_Withdraw.Text) <= 0)
            {
                MessageBox.Show("Withdraw Amount Can't be Less Than 1");
                txtbox_Withdraw.Clear();
                pnl_Withdraw.Visible = false;
                pnl_Main.Visible = true;
            }
            
            else if (Convert.ToDouble(txtbox_Withdraw.Text) <= Convert.ToDouble(dtUser.Rows[index][2]))
            {
                MessageBox.Show("Withdrawal Successful");
                dtUser.Rows[index][2] = Convert.ToDouble(dtUser.Rows[index][2]) - Convert.ToDouble(txtbox_Withdraw.Text);
                lbl_RpBalance.Text = Convert.ToDouble(dtUser.Rows[index][2]).ToString("C2").Remove(1, 0);
                txtbox_Withdraw.Clear();
                pnl_Withdraw.Visible = false;
                pnl_Main.Visible = true;
            }
            else
            {
                MessageBox.Show("Balance Insufficient");
                txtbox_Withdraw.Clear();
                pnl_Withdraw.Visible = false;
                pnl_Main.Visible = true;
            }
        }

        private void btn_Logout_Click_1(object sender, EventArgs e)
        {
            pnl_Login.Visible = true;
            pnl_Deposit.Visible = false;
            pnl_Main.Visible = false;
            pnl_Withdraw.Visible = false;
            index = 0;
        }
    }
}
